#Nomor 1

def cetakSiku(x):
    for x in range (x+1):
        print("*"*x)
        
#Nomor 2

def gambarlahPersegiEmpat(x,y):
    print ("@"*y)
    for i in range (0,x-2):
        print ("@"+" "*(y-2)+"@")
    print ("@"*y)

#Nomor 3

def jumlahHurufVokal(x):
    voc = "aiueoAIUEO"
    hVoc = 0
    for i in (x):
        if i in voc:
            hVoc += 1
    return (len(x),hVoc)


def jumlahHurufKonsonan(x):
    con = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTWVXYZ"
    hCon = 0
    for i in (x):
        if i in con:
            hCon += 1
    return (len(x),hCon)

#Nomor 4

def rerata(g):
    jm = sum(g)
    hasil = jm / len(g)
    return hasil

# Nomor 5

from math import sqrt as sq
def apakahPrima(n):
    n = int (n)
    assert n>=0
    primaKecil = [2,3,5,7,11]
    bukanPrKecil =[0,1,4,6,8,9,10]
    if n in primaKecil:
        return True
    elif n in bukanPrKecil:
        return False
    else:
        for i in range(2,int(sq(n))+1):
            if(n%i==0):
                return False
    return True

#Nomor 6

def bilanganPrima():
    prima=list()
    for i in range(2,1000):
        a = True
        for iter in prima:
            if(i%iter==0):
                a=False
                break
        if(a):
            print(i)
            prima.append(i)

#Nomor 7

def faktorPrima(n):
    prima=list()
    for i in range(2,n):
        a = True
        for iter in prima:
            if(i%iter==0):
                a=False
                break
        if a and n%i==0:
            prima.append(i)
    return prima

#Nomor 8

def apakahTerkandung(a,b):
    return a in b

#Nomor 9

def pythonUms(i):
    i = 1
    while i <= 100:
        if (i%3 == 0) and (i%5 == 0):
            print ("Pyhton UMS")
        elif (i%3 == 0):
            print ("Python")
        elif (i%5 == 0):
            print ("UMS")
        else:
            print (i)
        i = i+1

#Nomor 10

from math import sqrt as akar

def selesaikanABC(a,b,c):
    a = float(a)
    b = float(b)
    c = float(c)
    D = (b**2) - (4*a*c)
    
    if D < 0 :
        return "Determinannya negatif. Persamaan tidak mempunyai akar real."
    else :
        x1 = (-b + akar(D))/(2*a)
        x2 = (-b - akar(D))/(2*a)
        hasil = (x1, x2)
        return hasil

#Nomor 11
    
def apakahKabisat(n):
    if n%4==0:
        if n%100==0 and n%400==0:
            return True
        elif n%100==0 and n%400!=0:
            return False
        return True
    return False

#Nomor 12

import random
def tebakAngka():

    print ("Permainan tebak angka")
    print ("Saya menyimpan sebuah angka bulat antara 1 sampai 100. coba tebak.")

    z = 0
    jawaban = random.randint(0,100)
    i=0
    while z <= 1:
        i=i+1
        inp = int(input("Masukkan tebakan ke-{0} :>".format(i)))
        if inp < jawaban:
            print ("Itu terlalu kecil. Coba lagi")
    
        elif inp > jawaban :
            print ("Itu terlalu besar. Coba lagi")
        
        else :
            print ("Ya. Anda benar")
            break
    
# Nomor 13

def katakan(angka):
    satuan = ["satu", "dua", "tiga", "empat", "lima",
              "enam", "tujuh", "delapan", "sembilan", "sepuluh",
              "sebelas", "dua belas", "tiga belas", "empat belas", "lima belas",
              "enam belas", "tujuh belas", "delapan belas", "sembilan belas"
              ]
    angka = '{:0,.0f}'.format(int(angka))
    angka = angka.split(",")
    katakan = []
    idx = 1
    for x in angka[::-1]:
        seribu = False
        if idx == 2 and x[-1]!="0":
            if int(x)< 2 :
                katakan.append("seribu")
                seribu = True
            else:
                katakan.append("ribu")
        if idx == 3 and x[-1]!="0":
            katakan.append("juta")
        if seribu == False:
            if int(x[-2:])<20 and int(x[-2:])>0:
                katakan.append(satuan[int(x[-2:])-1])
            elif int(x[-2:])>0:
                if int(x[-1])!=0:
                    katakan.append(satuan[int(x[-1])-1])
                if int(x[-2]) != 0:
                    katakan.append(satuan[int(x[-2])-1]+" puluh")
        if int(x[0]) > 2 and len(x)==3 :
            katakan.append(satuan[int(x[0])-1]+" ratus")
        elif len(x)==3 and int(x[0])!=0 :
            katakan.append("seratus")
        idx+=1
    return " ".join(katakan[::-1])

#Nomor 14

def formatRupiah(n):
    x = '{:,}'.format(n).replace(',', '.')
    return "Rp " + x

